# Implementation Plan - Fix Self-Parsing JSON in ConstraintValidationTool

## Problem

The `ConstraintValidationTool` currently accepts a single `action_json: str` field and calls
`json.loads(action_json)` manually inside `_run()`. This is fragile and a well-known failure mode:
agents frequently produce malformed JSON strings (missing quotes, trailing commas, wrong escaping),
causing an uncaught `json.JSONDecodeError` that crashes the tool and the entire crew run.

> [!CAUTION]
> This is the most common cause of silent CrewAI tool failures. Never have an agent self-serialize
> and pass a JSON string when you can describe the same structure with typed Pydantic fields.

## Root Cause

```python
# BAD — agent must produce valid JSON string manually
class ConstraintValidationInput(BaseModel):
    action_json: str = Field(..., description="JSON string of the action plan step to validate")
    ...

def _run(self, action_json: str, ...) -> str:
    action = json.loads(action_json)   # ← CRASH-POINT if agent sends malformed JSON
```

## Fix

Replace the single opaque `action_json: str` with individual typed fields that mirror the
`action` dict keys consumed by `ConstraintEngine.validate_action()`. Pydantic validates and
coerces types before `_run()` is ever called.

```python
# GOOD — agent fills typed fields; no manual JSON parsing needed
class ConstraintValidationInput(BaseModel):
    action: str = Field(..., description="Short description of the action to validate")
    estimated_cost_usd: float = Field(0.0, description="Estimated cost of the action in USD")
    estimated_days: int = Field(0, description="Estimated days needed to complete the action")
    budget_usd: float = Field(5000.0, description="Available budget in USD")
    time_days: int = Field(30, description="Time limit in days")
    urgency: str = Field("HIGH", description="Urgency level: HIGH, MEDIUM, or LOW")
```

## Proposed Changes

### [founderlens_ai]

#### [MODIFY] [custom_tool.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/tools/custom_tool.py)
- Replace `action_json: str` with individual typed fields: `action`, `estimated_cost_usd`, `estimated_days`.
- Remove `import json` and `json.loads()` call from `_run()`.
- Build the action dict from typed fields inside `_run()`.
- Return a clean plain-text summary instead of a `json.dumps()` string (easier for agents to parse).

## Verification Plan

### Automated
- Validate that `custom_tool.py` can be imported without error.

### Manual
- Confirm no `json.loads` calls remain in the tool.
- Confirm the schema fields match what `ConstraintEngine.validate_action()` expects.
