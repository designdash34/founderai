# Walkthrough - Fix Self-Parsing JSON in ConstraintValidationTool

## Problem

The `ConstraintValidationTool` had a critical fragility: it accepted a single `action_json: str`
field and called `json.loads()` inside `_run()`. Agents routinely produce malformed JSON strings,
which caused an uncaught `json.JSONDecodeError` that crashed the tool and the entire crew run.

```python
# OLD — BROKEN
class ConstraintValidationInput(BaseModel):
    action_json: str = Field(..., description="JSON string of the action plan step to validate")

def _run(self, action_json: str, ...) -> str:
    action = json.loads(action_json)   # ← CRASH if agent sends bad JSON
```

## Fix Applied

Replaced the opaque `action_json: str` with individual **typed Pydantic fields**.
Pydantic now validates and coerces every value before `_run()` is called.
There is no JSON string to parse and no crash point.

```python
# NEW — SAFE
class ConstraintValidationInput(BaseModel):
    action: str           # plain string description
    estimated_cost_usd: float = 0.0
    estimated_days: int = 0
    budget_usd: float = 5000.0
    time_days: int = 30
    urgency: str = "HIGH"

def _run(self, action: str, estimated_cost_usd: float, ...) -> str:
    action_dict = {"action": action, "estimated_cost_usd": estimated_cost_usd, ...}
    result = engine.validate_action(action_dict, constraints)
    # Returns plain-text — easier for agents to read
```

## Additional Improvements

- **Plain-text output**: Instead of `json.dumps(result, indent=2)`, the tool now returns a
  human-readable summary. This makes it much easier for the agent to incorporate the
  validation result into its reasoning.
- **Removed `import json`**: No longer needed anywhere in the tool.

## Files Changed

| File | Change |
|------|--------|
| [custom_tool.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/tools/custom_tool.py) | Replaced `action_json: str` + `json.loads()` with typed Pydantic fields |

## Verification

```
Import OK  ✅
Exit code: 0
```

Module imports cleanly with no errors.
