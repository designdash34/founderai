# Implementation Plan — Resolving API Baseline Mode Discrepancy

This implementation plan addresses the critical gap where the **Non-Agentic Baseline Mode** (implemented in `baseline.py`) is completely omitted from the FastAPI REST API (`analyze.py`). 

Fixing this gap ensures complete alignment with the official Google Antigravity Hackathon guidelines, the main repository `README.md`, and Swagger API documentation.

---

## User Review Required

> [!IMPORTANT]
> **API Schema Compatibility**
>
> We will add the `baseline` boolean flag to the `AnalysisRequest` schema in [analyze.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/api/routes/analyze.py). 
> - **Default value**: `False` (runs the 6-agent boardroom crew).
> - **When set to `True`**: Runs the direct `FounderLensBaseline` class, saving a dedicated baseline record to the database and returning a schema-compatible response in ~1.5 seconds.
> - **No breaking changes**: All existing parameters (`problem_statement`, `url`, `scenario`, `startup_name`) will remain fully supported and functional.

---

## Proposed Changes

### Backend REST API

#### [MODIFY] [analyze.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/api/routes/analyze.py)

We will perform the following changes in the analysis router:

1.  **Import the Baseline Engine**:
    ```python
    from founderlens_ai.baseline import FounderLensBaseline
    ```

2.  **Update Pydantic Schema**:
    Add `baseline` to `AnalysisRequest` with a default of `False`:
    ```python
    class AnalysisRequest(BaseModel):
        business_problem: Optional[str] = Field(None, alias="problem_statement")
        website_url: Optional[str] = Field(None, alias="url")
        use_demo_data: bool = True
        input_types: List[str] = ["document", "structured", "web_intel"]
        pdf_path: Optional[str] = None
        csv_path: Optional[str] = None
        scenario: str = "saas_churn"
        startup_name: str = "Startup"
        baseline: bool = Field(False, description="Toggle to run in Non-Agentic Baseline Mode (single direct LLM call)")
    ```

3.  **Implement Router Execution Branch**:
    Inside `start_analysis()`, add a check for the `baseline` flag:
    ```python
    if request.baseline:
        # 1. Orchestrate Inputs
        unified_data = orchestrator.process(user_inputs, scenario=request.scenario)
        
        # 2. Run Non-Agentic Baseline
        baseline_engine = FounderLensBaseline()
        baseline_result = await baseline_engine.run({
            "startup_name": request.startup_name,
            "data_sources": unified_data["sources"]
        })
        
        if baseline_result["status"] == "error":
            raise HTTPException(status_code=500, detail=baseline_result["error"])
            
        # 3. Format Baseline Data for DB and Response
        result_data = baseline_result["result"]
        insights_list = result_data.get("insights", [])
        
        analysis_record = {
            "session_id": session_id,
            "startup_name": f"{request.startup_name} (Baseline)",
            "insights": insights_list,
            "contradictions": result_data.get("contradictions", []),
            "action_chain": result_data.get("action_chain", []),
            "simulation_result": result_data.get("simulation_result", {}),
            "raw_result": json.dumps(result_data),
            "total_runtime_seconds": baseline_result["total_runtime_seconds"],
            "cost_estimate_usd": 0.005 # Baseline runs use fewer tokens
        }
        
        # Save to database if active
        from founderlens_ai.db.database import db_manager
        if db_manager.is_active():
            try:
                db_manager.client.table("analysis_results").insert(analysis_record).execute()
            except Exception as db_err:
                logger.log_event("API", "ERROR", "System", {"message": f"Supabase baseline save failed: {str(db_err)}"})
                
        # Save locally as fallback
        try:
            log_dir = os.getenv("LOG_DIR", "./logs")
            os.makedirs(log_dir, exist_ok=True)
            results_path = os.path.join(log_dir, "analysis_results.json")
            
            local_results = []
            if os.path.exists(results_path):
                with open(results_path, "r") as f:
                    local_results = json.load(f)
            local_results.append(analysis_record)
            with open(results_path, "w") as f:
                json.dump(local_results, f, indent=2)
        except Exception as file_err:
            logger.log_event("API", "ERROR", "System", {"message": f"Local baseline save failed: {str(file_err)}"})
            
        return {
            "id": session_id,
            "trace_id": session_id,
            "status": "success",
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "agents_involved": 1, # Direct LLM
            "execution_time_ms": int(baseline_result["total_runtime_seconds"] * 1000),
            "insights": insights_list,
            "raw_result": json.dumps(result_data)
        }
    ```

---

## Verification Plan

### Automated / API Verification
We will run and verify the behavior using local API tests:

1.  **Test 1 (Default / Agentic Mode)**:
    Send a `POST /api/v1/analysis/start` request with `"baseline": false` or omitted.
    - **Expected Outcome**: Runs the full CrewAI boardroom (takes 20-30 seconds), returns status `success` and `agents_involved: 6`.

2.  **Test 2 (Baseline Mode)**:
    Send a `POST /api/v1/analysis/start` request with `"baseline": true`.
    - **Expected Outcome**: Runs in **~1-2 seconds**, returns status `success` and `agents_involved: 1` with insights parsed from the direct Gemini call, fully recorded in `logs/analysis_results.json`.

3.  **Test 3 (Swagger / Docs Verification)**:
    Verify that Swagger UI (`/docs`) displays the new `baseline` parameter inside the schema models.
