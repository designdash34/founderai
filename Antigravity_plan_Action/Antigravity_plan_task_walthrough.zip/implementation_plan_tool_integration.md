# Implementation Plan - Add Searching Capability for Agents

The goal is to add a custom searching tool to the agents so they can perform internet searches, specifically for competitor research.

## User Review Required

> [!IMPORTANT]
> To use the search functionality, a `SERPER_API_KEY` is required from [serper.dev](https://serper.dev/). Please add this key to your `.env` file.

> [!NOTE]
> Based on feedback, the `CompetitorSearchTool` will be enhanced with custom logic (domain filtering and result prioritization) to provide more value than a simple wrapper. It will also be wired to the `insight_agent`.

## Proposed Changes

### [founderlens_ai]

#### [MODIFY] [custom_tool.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/tools/custom_tool.py)
- Enhance `CompetitorSearchTool` with custom logic for filtering and prioritizing search results.
- Remove the placeholder `MyCustomTool`.

#### [MODIFY] [crew.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/crew.py)
- Import `CompetitorSearchTool`.
- Attach the tool to the `insight_agent`.

## Verification Plan

### Manual Verification
1.  Check if `CompetitorSearchTool` is correctly defined in `custom_tool.py`.
2.  Verify that `SERPER_API_KEY` placeholder exists in `.env`.
3.  (Optional) If an API key is provided, run a small test script to verify search results.
