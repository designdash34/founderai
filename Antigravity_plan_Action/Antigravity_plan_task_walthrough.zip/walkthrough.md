# 🚀 Technical Walkthrough: FounderLens AI

**Team**: Byte Minds  
**Project**: FounderLens AI — Autonomous Boardroom & Action Engine  
**Hackathon**: Google Antigravity 2026

## 🌟 Executive Summary
FounderLens AI is a deterministic decision engine designed to eliminate "Founder Blindness." Using the **Antigravity Orchestrator Layer**, the system validates business data across 5 distinct sources, resolves cross-source conflicts, and simulates future outcomes before any capital is deployed.

---

## 🛠️ Core Technology Stack
- **Orchestration**: CrewAI + LangChain
- **LLM Engine**: Google Gemini 2.5 Flash Lite (All 6 Agents)
- **API Framework**: FastAPI (Uvicorn)
- **Data Science**: Pandas, PyMuPDF, BeautifulSoup4
- **Audit Layer**: Antigravity Trace Layer (Structured JSON + Markdown)

---

## 📐 The Byte Minds "5-Source" Protocol
The system enforces a mandatory multi-modal ingestion flow to ensure data integrity:
1.  **TYPE 1: Document** (PDF Reports) — Strategic context and stated goals.
2.  **TYPE 2: Structured** (CSV/JSON) — Raw financial and retention metrics.
3.  **TYPE 3: Web Intel** (News/URLs) — External market sentiment and competitor signals.
4.  **TYPE 4: Dashboard** (KPIs) — Real-time health classification (Critical/Warning/Healthy).
5.  **TYPE 5: Real-time** (Live Feed) — Simulated data spikes for immediate reaction.

---

## 🤖 The Autonomous Boardroom (6 Agents)
We implemented a sequential reasoning chain that mimics a high-performance executive board:
- **Intake Agent**: Ingests and validates the 5 sources.
- **Insight Agent**: Detects patterns, risks, and "silent" opportunities.
- **Conflict Agent**: Audits contradictions between sources (e.g., PDF vs CSV).
- **Planner Agent**: Generates a realistic 3–5 step action chain with target metrics.
- **Simulation Agent**: Projects the "Before vs After" impact of the plan.
- **Recovery Agent**: Final audit of the entire execution trace for reliability.

---

## 🕵️ The Antigravity Advantage
- **Deterministic Workplan**: Every session starts with an Orchestrator Workplan log before any agent speaks.
- **Antigravity Trace Layer**: Every decision is recorded in `antigravity_trace.json`, providing a machine-readable audit trail.
- **Never-Block Policy**: If data is missing, the system auto-filled with high-fidelity demo scenarios, ensuring the demo never fails.

---

## 📂 Submission Contents (`submit_plan/`)
- `implementation_plan.md`: The technical blueprint.
- `task.md`: The execution tracker.
- `working.md`: Technical guide for internal team sync.
- `demo_script.md`: The 3-minute pitch and demo sequence.
- `walkthrough.md`: This comprehensive technical overview.
- `antigravity_trace.json`: (Generated at runtime) Proof of deterministic reasoning.

---

**Developed with ❤️ by Team Byte Minds using Google Gemini.**
