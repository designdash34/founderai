# Tasks — Baseline Mode API Integration

- `[x]` Add `baseline` field to `AnalysisRequest` and import `FounderLensBaseline`
- `[x]` Implement baseline execution routing logic in POST `/start` handler
- `[x]` Persist baseline results to database and local JSON file
- `[x]` Verify system execution
    - `[x]` Run and verify agentic mode (baseline=false)
    - `[x]` Run and verify baseline mode (baseline=true)
    - `[x]` Verify Swagger docs show updated schema
- `[x]` Generate walkthrough documentation summarizing outcomes
