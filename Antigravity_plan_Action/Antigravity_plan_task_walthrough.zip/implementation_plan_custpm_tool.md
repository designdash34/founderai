# Implementation Plan - Add Searching Capability for Agents

The goal is to add a custom searching tool to the agents so they can perform internet searches, specifically for competitor research.

## User Review Required

> [!IMPORTANT]
> To use the search functionality, a `SERPER_API_KEY` is required from [serper.dev](https://serper.dev/). Please add this key to your `.env` file after the implementation.

## Proposed Changes

### [founderlens_ai]

#### [MODIFY] [custom_tool.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/tools/custom_tool.py)
- Import `SerperDevTool` from `crewai_tools`.
- Define `CompetitorSearchTool` class that inherits from `BaseTool`.
- Alternatively, we can just use `SerperDevTool` directly in the crew configuration, but since the user specifically asked to update `custom_tool.py`, I will create a specialized tool there that wraps `SerperDevTool` or implements a search logic.
- I will implement a `CompetitorSearchTool` that uses `SerperDevTool` internally to provide a clean interface for agents to search for competitor information.

#### [MODIFY] [.env](file:///home/mouzan/Desktop/founderlens_ai/.env)
- Add `SERPER_API_KEY` placeholder.

## Verification Plan

### Manual Verification
1.  Check if `CompetitorSearchTool` is correctly defined in `custom_tool.py`.
2.  Verify that `SERPER_API_KEY` placeholder exists in `.env`.
3.  (Optional) If an API key is provided, run a small test script to verify search results.
