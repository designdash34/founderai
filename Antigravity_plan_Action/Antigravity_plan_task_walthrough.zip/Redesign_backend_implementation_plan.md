# 🎨 Implementation Plan: App-Ready FastAPI Redesign

To make the backend perfect for your teammate's mobile app, we are upgrading the API from a simple "Request-Response" model to a **Stateful Interaction Model**.

## 🚀 Key Upgrades

### 1. Robust Schema Validation
- Use **Pydantic V2** for every request and response.
- Add field descriptions so Swagger (`/docs`) explains exactly what each field does.

### 2. Trace Retrieval Endpoint (`/api/trace/{session_id}`)
- The teammate needs to fetch the **Antigravity Trace JSON** independently of the analysis result.
- This endpoint will return the live history of agent reasoning and tool calls.

### 3. Execution Status Tracking
- Instead of the frontend "hanging" while agents work, we provide a session-based status.
- Add `GET /api/status/{session_id}`.

### 4. Direct JSON Result Extraction
- Separate the "Final Boardroom Decision" from the "Trace Logs" so the UI can display them in different sections.

---

## 🛠️ Proposed Changes

### [Component] API Layer

#### [MODIFY] [main.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/api/main.py)
- Add Global Exception Handlers.
- Add custom lifespan events for cleaning up old logs.

#### [MODIFY] [analyze.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/api/routes/analyze.py)
- Refactor into a **Clean Architecture** pattern.
- Implement the new response models.

#### [NEW] [trace.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/api/routes/trace.py)
- Endpoint to serve the `antigravity_trace.json` filtered by session.

---

## ✅ Verification Plan

### Automated Tests
1. Run `uvicorn` and verify that `/docs` shows the new "Byte Minds" documentation.
2. Use `curl` to simulate a mobile app request and verify the JSON structure matches the mockup.

### Manual Verification
1. Ask the teammate if the new JSON structure is easy to map to their UI widgets (MRR, Churn, NPS).
