# 🚀 Zero-Latency Discord Action Integration Plan

## Goal Description
We will implement a real-world live outbound Discord notification action inside your FastAPI boardroom simulation backend. 

To ensure complete immunity to network timeouts and keep your Android app's latency extremely low, we will transition the execution flow to use **FastAPI's native `BackgroundTasks`**. 

This allows your server to instantly send the boardroom analysis results back to the Android client, terminate the connection, and then execute the webhook payload post inside a separate background thread pool.

---

## Technical Solution

### The Latency Gotcha:
A standard HTTP call using Python's `requests` library is **synchronous and blocking**. Even when launched inside a standard `asyncio.create_task()`, the single-threaded python loop freezes while resolving DNS, doing SSL handshakes, and waiting for Discord's API response. This delay is what caused the Android network client (with its timeout boundaries) to trigger connection error toasts.

### The FastAPI Native Solution:
By utilizing FastAPI's **`BackgroundTasks` worker pool**, we schedule the synchronous Discord webhook execution to take place *after* the HTTP response has been successfully sent to the Android app and the connection is closed. 
* **Added Latency on Android:** `0 milliseconds`
* **Timeout Risk:** `0%`

---

## Proposed Changes

### [Component: Backend Router]

#### [MODIFY] [analyze.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/api/routes/analyze.py)

1.  **Import BackgroundTasks:**
    ```python
    from fastapi import APIRouter, HTTPException, Body, BackgroundTasks
    ```

2.  **Define `trigger_live_discord_webhook` Helper:**
    Create a robust helper function that reads `DISCORD_WEBHOOK_URL` from the environment, builds a premium rich embed (capturing startup name, session ID, primary boardroom insight, and the step-by-step sequential action chain), and performs the webhook post.

3.  **Update Endpoint Signature:**
    Inject `background_tasks: BackgroundTasks` directly into the `/start` route handler:
    ```python
    async def start_analysis(request: AnalysisRequest, background_tasks: BackgroundTasks):
    ```

4.  **Register Background Task:**
    At the bottom of the handler (after saving all caching records), register the webhook trigger:
    ```python
    background_tasks.add_task(trigger_live_discord_webhook, session_id, request.startup_name, formatted_insights, action_chain)
    ```

---

## Verification Plan

### Automated/Manual Testing:
1.  Verify the backend syntax compiles successfully:
    ```bash
    python3 -m py_compile src/founderlens_ai/api/routes/analyze.py
    ```
2.  Start the FastAPI server.
3.  Trigger an AI Courtroom Analysis from your Android app.
4.  Verify that:
    *   The mobile app receives the courtroom analysis response instantly and updates the UI without any timeout toasts.
    *   The Discord channel immediately populates the rich boardroom notificationembed.
