# 🏛️ Implementation Plan: Hackathon Architecture Improvements

To ensure **FounderLens AI** is fully compliant with the Google Antigravity Hackathon requirements (Challenge 1), we are implementing several critical features: Baseline Comparison, Cost/Latency Tracking, and expanded documentation.

## User Review Required

> [!IMPORTANT]
> **Mobile App Mandatory**: While I am improving the backend to support mobile data, you still need to ensure your Mobile APK connects to these new fields in the Supabase database.

## Proposed Changes

### [Component] Backend Core (Metrics & Baseline)

#### [MODIFY] [logger.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/utils/logger.py)
- Update `AntigravityLogger` to support `total_cost` and `total_latency` fields.
- Add a method to calculate USD cost based on Gemini 2.5 Flash Lite token pricing.

#### [MODIFY] [crew.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/crew.py)
- Capture `usage_metrics` after kickoff.
- Implement `FounderLensBaseline` class to provide a non-agentic comparison as required by the hackathon.

#### [MODIFY] [analyze.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/api/routes/analyze.py)
- Add a `baseline` boolean flag to the `AnalysisRequest`.
- Return `usage_metrics`, `cost_estimate`, and `total_runtime` in the API response.
- Save these metrics to Supabase for mobile app visualization.

### [Component] Documentation

#### [MODIFY] [README.md](file:///home/mouzan/Desktop/founderlens_ai/README.md)
- Add sections for **Privacy & Safety**, **Scalability Discussion**, **Data Schemas**, and **Cost Analysis**.

---

## ✅ Verification Plan

### Automated Tests
1. Run `POST /api/analyze` with `baseline=true` and verify it returns a simplified response.
2. Run `POST /api/analyze` with `baseline=false` and verify `usage_metrics` and `cost_estimate` are present.
3. Check Supabase to ensure `analysis_results` now includes `total_runtime` and `cost_estimate`.

### Manual Verification
1. Verify that the Antigravity Trace log in the console shows the cost and latency for the entire run.
