# Implementation Plan — Android Frontend Baseline Toggle Integration

This plan implements a high-fidelity **Material Switch** inside the Android mobile app frontend to allow developers and judges to toggle **Non-Agentic Baseline Mode** directly from the UI. This switch connects directly to our updated backend API.

---

## Proposed Changes

### Android Frontend Components

#### [MODIFY] [AnalysisRequest.java](file:///home/mouzan/Desktop/founderlens_ai/frontend/FounderLensAI/app/src/main/java/com/founderlens/ai/models/AnalysisRequest.java)
We will add serialization mapping for the `baseline` field:
*   Add the `@SerializedName("baseline")` boolean field.
*   Add `isBaseline()` and `setBaseline()` getter and setter methods.

---

#### [MODIFY] [fragment_upload.xml](file:///home/mouzan/Desktop/founderlens_ai/frontend/FounderLensAI/app/src/main/res/layout/fragment_upload.xml)
We will insert a Material Switch immediately above the **START AI PROCESSING** button:
*   Add `<com.google.android.material.materialswitch.MaterialSwitch>` with id `@+id/switch_baseline`.
*   Style it to match the existing Outfit/sans-serif typography and Material 3 design tokens.

---

#### [MODIFY] [UploadFragment.java](file:///home/mouzan/Desktop/founderlens_ai/frontend/FounderLensAI/app/src/main/java/com/founderlens/ai/fragments/UploadFragment.java)
We will bind the toggle switch to the network request:
*   Declare the `MaterialSwitch` reference.
*   Bind the switch in `onViewCreated()` using `findViewById()`.
*   Set `request.setBaseline(switchBaseline.isChecked())` inside `sendToApi()`.
*   Update `startProcessing()` status text to reflect when the baseline analysis starts (i.e. `"⚖️ Running direct single-prompt LLM analyst baseline..."` versus `"📤 Uploading files to backend..."`).

---

## Verification Plan

### Manual Verification
1.  Open the Android App in the emulator or target device.
2.  Navigate to the Upload screen.
3.  **Test 1 (Standard Mode)**:
    - Keep **Run Non-Agentic Baseline** checked as **OFF**.
    - Click **Start AI Processing**.
    - Verify that the processing status cycles through sequential boardroom agent messages (`Intake Agent`, `Insight Agent`, `Conflict Agent`, etc.) and takes ~20-25s.
4.  **Test 2 (Baseline Mode)**:
    - Toggle **Run Non-Agentic Baseline** to **ON**.
    - Click **Start AI Processing**.
    - Verify that the status instantly reads `⚖️ Running direct single-prompt LLM analyst baseline...` and completes successfully in **~1-3 seconds**, navigating directly to the insights tab!
