# 🌐 Implementation Plan: Database & Deployment Redesign

To prepare FounderLens AI for **Railway Deployment** and a **Mobile APK Frontend**, we are migrating from local logging to a **Cloud-Native Database Architecture**.

## 🚀 Architectural Shift: Supabase + Railway

### 1. Database Selection: Supabase (PostgreSQL)
- **Why**: Native support for real-time JSON streaming (perfect for the Antigravity Trace) and easy integration with Railway and Mobile SDKs.
- **Role**: Serves as the persistent "ledger" for all boardroom decisions and audit trails.

### 2. Deployment Strategy
- **Backend**: Hosted on **Railway** (Auto-deploys from GitHub).
- **Database**: **Supabase** (PostgreSQL + Auth + Storage).
- **Frontend**: **Mobile APK** (connecting via Supabase Realtime).

---

## 📐 Database Schema Design

### Table: `sessions`
- `id` (UUID, Primary Key)
- `startup_name` (Text)
- `scenario` (Text)
- `created_at` (Timestamp)

### Table: `analysis_results`
- `session_id` (UUID, Foreign Key)
- `insights` (JSONB)
- `contradictions` (JSONB)
- `action_chain` (JSONB)
- `simulation_result` (JSONB)

### Table: `antigravity_trace`
- `id` (BigInt)
- `session_id` (UUID)
- `timestamp` (Timestamp)
- `layer` (Text)
- `agent` (Text)
- `data` (JSONB) — *This is where the live "Thinking" logs go.*

---

## 🛠️ Proposed Changes

### [Component] Backend Core

#### [MODIFY] [logger.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/utils/logger.py)
- Integrate `supabase-py`.
- Update `log_event` to asynchronously push logs to the `antigravity_trace` table.

#### [MODIFY] [analyze.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/api/routes/analyze.py)
- Save final boardroom results to `analysis_results` before returning the response.

#### [NEW] [database.py](file:///home/mouzan/Desktop/founderlens_ai/src/founderlens_ai/db/database.py)
- Supabase client initialization and singleton management.

---

## ✅ Verification Plan

### Automated Tests
1. Verify that `POST /api/analyze` successfully inserts a row into Supabase.
2. Verify that the Trace API can fetch logs from the DB instead of the local JSON file.

### Manual Verification
1. Open the Supabase Dashboard and watch the `antigravity_trace` table update in real-time as the boardroom runs.
