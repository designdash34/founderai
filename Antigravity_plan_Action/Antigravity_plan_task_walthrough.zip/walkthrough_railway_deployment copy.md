# Railway Deployment Guide — FounderLens AI

## Files Created

| File | Purpose |
|------|---------|
| `Dockerfile` | Multi-stage build: installs deps with `uv`, then copies only runtime files |
| `.dockerignore` | Excludes `.venv`, `.env`, logs, uploads, frontend from the image |
| `railway.toml` | Tells Railway to use Dockerfile, sets start command & health check |
| `.env.example` | Template for all environment variables to set in Railway dashboard |

## Step-by-Step Deployment

### 1. Push your code to GitHub
```bash
git add Dockerfile .dockerignore railway.toml .env.example
git commit -m "feat: add Railway deployment config"
git push origin main
```

### 2. Create a Railway project
1. Go to [railway.app](https://railway.app) → **New Project**
2. Select **Deploy from GitHub repo**
3. Choose your `founderlens_ai` repository

### 3. Set Environment Variables
In Railway dashboard → your service → **Variables**, add:

| Variable | Value | Required |
|----------|-------|----------|
| `GEMINI_API_KEY` | Your Google Gemini key | ✅ |
| `SERPER_API_KEY` | Your Serper.dev key | ✅ (for search) |
| `GROQ_API_KEY` | Your Groq key | Optional |
| `SUPABASE_URL` | Your Supabase project URL | Optional |
| `SUPABASE_KEY` | Your Supabase anon key | Optional |
| `MODEL` | `google/gemini-2.5-flash-lite` | ✅ |
| `ENVIRONMENT` | `production` | ✅ |
| `LOG_DIR` | `/app/logs` | ✅ |

> [!CAUTION]
> **Never set `PORT`** — Railway injects it automatically.

### 4. Deploy
Railway will automatically:
1. Detect the `Dockerfile`
2. Build the image (uv installs deps from `uv.lock`)
3. Run the health check at `/`
4. Assign a public URL like `https://founderlens-ai.up.railway.app`

### 5. Verify
Visit `https://your-service.up.railway.app/docs` for the full Swagger UI.

Health check endpoint: `GET /` → returns `{"status": "online"}`

## Local Docker Test (before pushing)
```bash
# Build
docker build -t founderlens-ai .

# Run (simulate Railway env)
docker run -p 8000:8000 \
  -e GEMINI_API_KEY=your_key \
  -e SERPER_API_KEY=your_key \
  -e MODEL=google/gemini-2.5-flash-lite \
  -e ENVIRONMENT=production \
  -e LOG_DIR=/app/logs \
  founderlens-ai

# Test
curl http://localhost:8000/
```
